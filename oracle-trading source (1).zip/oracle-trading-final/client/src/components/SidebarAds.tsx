import { useEffect } from 'react';

/**
 * Sidebar AdSense Component (300x250 - Medium Rectangle)
 * 가장 높은 CPM을 가진 광고 형식
 */

export default function SidebarAds() {
  useEffect(() => {
    try {
      if ((window as any).adsbygoogle) {
        (window as any).adsbygoogle.push({});
      }
    } catch (error) {
      console.error('AdSense error:', error);
    }
  }, []);

  return (
    <div className="sticky top-24 space-y-6">
      {/* Ad 1 - Medium Rectangle */}
      <div className="card-gold-glow p-4">
        <ins
          className="adsbygoogle"
          style={{
            display: 'block',
            width: '300px',
            height: '250px',
          }}
          data-ad-client="ca-pub-6870676006996989"
          data-ad-slot="1234567890"
          data-ad-format="rectangle"
        />
      </div>

      {/* Ad 2 - Medium Rectangle */}
      <div className="card-gold-glow p-4">
        <ins
          className="adsbygoogle"
          style={{
            display: 'block',
            width: '300px',
            height: '250px',
          }}
          data-ad-client="ca-pub-6870676006996989"
          data-ad-slot="1234567891"
          data-ad-format="rectangle"
        />
      </div>

      {/* Ad 3 - Medium Rectangle */}
      <div className="card-gold-glow p-4">
        <ins
          className="adsbygoogle"
          style={{
            display: 'block',
            width: '300px',
            height: '250px',
          }}
          data-ad-client="ca-pub-6870676006996989"
          data-ad-slot="1234567892"
          data-ad-format="rectangle"
        />
      </div>
    </div>
  );
}
