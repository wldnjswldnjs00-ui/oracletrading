import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface EducationSection {
  title: string;
  content: string;
}

interface EducationAccordionProps {
  sections: EducationSection[];
}

export function EducationAccordion({ sections }: EducationAccordionProps) {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  return (
    <div className="space-y-3">
      {sections.map((section, index) => (
        <div
          key={index}
          className="border border-primary/20 rounded-lg overflow-hidden bg-card/50 hover:bg-card/70 transition-colors"
        >
          <button
            onClick={() => setExpandedIndex(expandedIndex === index ? null : index)}
            className="w-full px-4 py-3 flex items-center justify-between hover:bg-primary/5 transition-colors"
          >
            <h4 className="text-sm font-semibold text-foreground text-left">{section.title}</h4>
            <ChevronDown
              className={`w-4 h-4 text-gold transition-transform ${
                expandedIndex === index ? 'rotate-180' : ''
              }`}
            />
          </button>

          {expandedIndex === index && (
            <div className="px-4 py-3 border-t border-primary/10 bg-background/50">
              <div className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap">
                {section.content}
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
