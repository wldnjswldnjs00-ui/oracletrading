import { AlertTriangle, AlertCircle, CheckCircle } from 'lucide-react';

/**
 * Risk Indicator Component
 * 
 * Visual traffic light system for risk assessment
 */

export interface RiskIndicatorProps {
  capitalRequired: number;
  winRate: number;
  profitRatio: number;
  lossRatio: number;
}

export function RiskIndicator({ capitalRequired, winRate, profitRatio, lossRatio }: RiskIndicatorProps) {
  let riskLevel: 'low' | 'moderate' | 'high' | 'extreme' = 'low';
  let riskColor = 'text-green-500';
  let bgColor = 'bg-green-500/10';
  let borderColor = 'border-green-500/30';
  let icon = <CheckCircle className="w-5 h-5" />;
  let message = 'Low Risk';

  // Determine risk level based on multiple factors
  if (capitalRequired > 100000 || winRate < 40 || (profitRatio / lossRatio) < 1) {
    riskLevel = 'extreme';
    riskColor = 'text-destructive';
    bgColor = 'bg-destructive/10';
    borderColor = 'border-destructive/30';
    icon = <AlertTriangle className="w-5 h-5" />;
    message = 'Extreme Risk';
  } else if (capitalRequired > 50000 || winRate < 45 || (profitRatio / lossRatio) < 1.5) {
    riskLevel = 'high';
    riskColor = 'text-orange-500';
    bgColor = 'bg-orange-500/10';
    borderColor = 'border-orange-500/30';
    icon = <AlertTriangle className="w-5 h-5" />;
    message = 'High Risk';
  } else if (capitalRequired > 10000 || winRate < 50 || (profitRatio / lossRatio) < 2) {
    riskLevel = 'moderate';
    riskColor = 'text-yellow-500';
    bgColor = 'bg-yellow-500/10';
    borderColor = 'border-yellow-500/30';
    icon = <AlertCircle className="w-5 h-5" />;
    message = 'Moderate Risk';
  }

  return (
    <div className={`p-4 rounded-lg border ${bgColor} ${borderColor}`}>
      <div className="flex items-center gap-3">
        <div className={riskColor}>{icon}</div>
        <div className="flex-1">
          <p className={`font-semibold ${riskColor}`}>{message}</p>
          <p className="text-xs text-muted-foreground mt-1">
            {riskLevel === 'extreme' && 'Extreme caution required. Consider reducing position sizes.'}
            {riskLevel === 'high' && 'Significant risk. Monitor positions closely.'}
            {riskLevel === 'moderate' && 'Reasonable risk level. Proceed with caution.'}
            {riskLevel === 'low' && 'Risk level is manageable. Proceed with confidence.'}
          </p>
        </div>
      </div>
    </div>
  );
}

/**
 * Risk Gauge Component
 * 
 * Visual gauge showing risk level
 */

export interface RiskGaugeProps {
  value: number; // 0-100
  label?: string;
}

export function RiskGauge({ value, label = 'Risk Level' }: RiskGaugeProps) {
  let color = 'from-green-500 to-green-600';
  let textColor = 'text-green-500';

  if (value > 75) {
    color = 'from-destructive to-red-600';
    textColor = 'text-destructive';
  } else if (value > 50) {
    color = 'from-orange-500 to-orange-600';
    textColor = 'text-orange-500';
  } else if (value > 25) {
    color = 'from-yellow-500 to-yellow-600';
    textColor = 'text-yellow-500';
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold text-muted-foreground">{label}</p>
        <p className={`text-lg font-bold ${textColor}`}>{value.toFixed(0)}%</p>
      </div>
      <div className="w-full h-2 bg-card rounded-full overflow-hidden border border-primary/20">
        <div
          className={`h-full bg-gradient-to-r ${color} transition-all duration-300`}
          style={{ width: `${Math.min(value, 100)}%` }}
        />
      </div>
    </div>
  );
}

/**
 * Status Badge Component
 * 
 * Small status indicator badge
 */

export interface StatusBadgeProps {
  status: 'success' | 'warning' | 'error' | 'info';
  label: string;
}

export function StatusBadge({ status, label }: StatusBadgeProps) {
  const statusConfig = {
    success: { bg: 'bg-green-500/10', text: 'text-green-500', border: 'border-green-500/30' },
    warning: { bg: 'bg-yellow-500/10', text: 'text-yellow-500', border: 'border-yellow-500/30' },
    error: { bg: 'bg-destructive/10', text: 'text-destructive', border: 'border-destructive/30' },
    info: { bg: 'bg-primary/10', text: 'text-primary', border: 'border-primary/30' },
  };

  const config = statusConfig[status];

  return (
    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold border ${config.bg} ${config.text} ${config.border}`}>
      {label}
    </span>
  );
}
