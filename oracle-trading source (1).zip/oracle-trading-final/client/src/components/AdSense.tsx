import { useEffect } from 'react';

interface AdSenseProps {
  slot: string;
  format?: 'auto' | 'horizontal' | 'vertical' | 'rectangle';
  responsive?: boolean;
  style?: React.CSSProperties;
}

/**
 * Google AdSense Component
 * 
 * Usage:
 * <AdSense slot="1234567890" format="auto" responsive={true} />
 */

export default function AdSense({ slot, format = 'auto', responsive = true, style }: AdSenseProps) {
  useEffect(() => {
    try {
      // Push ads if window.adsbygoogle exists
      if ((window as any).adsbygoogle) {
        (window as any).adsbygoogle.push({});
      }
    } catch (error) {
      console.error('AdSense error:', error);
    }
  }, []);

  return (
    <div style={{ margin: '20px 0', ...style }}>
      <ins
        className="adsbygoogle"
        style={{
          display: 'block',
          textAlign: 'center',
          ...(responsive && { width: '100%', height: 'auto' }),
        }}
        data-ad-client="ca-pub-6870676006996989"
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive={responsive}
      />
    </div>
  );
}
