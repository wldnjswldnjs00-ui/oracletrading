/**
 * Trading Oracle Calculator Utilities
 * 
 * Core mathematical functions for investment calculations
 */

/**
 * Compound Interest Calculator
 * Calculates final amount with regular monthly investments
 * 
 * Formula: FV = P(1+r)^n + PMT × [((1+r)^n - 1) / r]
 * Where:
 * - P = Initial principal
 * - r = Monthly interest rate
 * - n = Number of months
 * - PMT = Monthly payment
 */
export interface CompoundCalculationResult {
  finalAmount: number;
  totalInvested: number;
  totalProfit: number;
  monthlyData: Array<{
    month: number;
    balance: number;
    invested: number;
    profit: number;
  }>;
}

export function calculateCompoundInterest(
  initialCapital: number,
  monthlyReturn: number,
  monthlyInvestment: number,
  months: number
): CompoundCalculationResult {
  const monthlyRate = monthlyReturn / 100;
  const monthlyData = [];
  
  let balance = initialCapital;
  let totalInvested = initialCapital;
  
  for (let i = 1; i <= months; i++) {
    // Apply monthly return
    balance = balance * (1 + monthlyRate) + monthlyInvestment;
    totalInvested += monthlyInvestment;
    
    const profit = balance - totalInvested;
    
    monthlyData.push({
      month: i,
      balance: Math.round(balance * 100) / 100,
      invested: Math.round(totalInvested * 100) / 100,
      profit: Math.round(profit * 100) / 100,
    });
  }
  
  const finalData = monthlyData[monthlyData.length - 1];
  
  return {
    finalAmount: finalData.balance,
    totalInvested: finalData.invested,
    totalProfit: finalData.profit,
    monthlyData,
  };
}

/**
 * Kelly Criterion Calculator
 * Determines optimal position sizing based on win rate and risk-reward ratio
 * 
 * Formula: f* = (bp - q) / b
 * Where:
 * - f* = Fraction of bankroll to bet
 * - b = Odds (profit ratio)
 * - p = Probability of winning
 * - q = Probability of losing (1 - p)
 */
export interface KellyResult {
  fullKelly: number;
  halfKelly: number;
  quarterKelly: number;
  aggressiveGuidance: string;
  conservativeGuidance: string;
}

export function calculateKellyCriterion(
  winRate: number,
  profitRatio: number,
  lossRatio: number
): KellyResult {
  const p = winRate / 100;
  const q = 1 - p;
  const b = profitRatio / lossRatio;
  
  // Kelly formula: f* = (bp - q) / b
  const fullKelly = (b * p - q) / b;
  const halfKelly = fullKelly / 2;
  const quarterKelly = fullKelly / 4;
  
  // Ensure non-negative values
  const safeFullKelly = Math.max(0, fullKelly);
  const safeHalfKelly = Math.max(0, halfKelly);
  const safeQuarterKelly = Math.max(0, quarterKelly);
  
  let aggressiveGuidance = '';
  let conservativeGuidance = '';
  
  if (safeFullKelly <= 0) {
    aggressiveGuidance = 'Do not trade. Expected value is negative.';
    conservativeGuidance = 'Do not trade. Expected value is negative.';
  } else if (safeFullKelly < 0.02) {
    aggressiveGuidance = 'Trade with extreme caution. Position size should be minimal.';
    conservativeGuidance = 'Avoid trading. Risk-reward ratio is unfavorable.';
  } else if (safeFullKelly < 0.05) {
    aggressiveGuidance = `Use ${(safeFullKelly * 100).toFixed(2)}% of bankroll (Full Kelly). High risk.`;
    conservativeGuidance = `Use ${(safeQuarterKelly * 100).toFixed(2)}% of bankroll (Quarter Kelly). Safer approach.`;
  } else {
    aggressiveGuidance = `Use ${(safeFullKelly * 100).toFixed(2)}% of bankroll (Full Kelly). Optimal growth.`;
    conservativeGuidance = `Use ${(safeHalfKelly * 100).toFixed(2)}% of bankroll (Half Kelly). Balanced approach.`;
  }
  
  return {
    fullKelly: Math.round(safeFullKelly * 10000) / 100,
    halfKelly: Math.round(safeHalfKelly * 10000) / 100,
    quarterKelly: Math.round(safeQuarterKelly * 10000) / 100,
    aggressiveGuidance,
    conservativeGuidance,
  };
}

/**
 * Martingale/Pyramiding Simulator
 * Simulates entry strategy with custom drawdown levels and position scaling
 * Uses compound (multiplicative) price drop per level for accuracy
 */
export interface MartingaleLevel {
  level: number;
  price: number;
  positionSize: number;
  cumulativeSize: number;
  cumulativeCapital: number;
  averagePrice: number;
}

export interface MartingaleResult {
  levels: MartingaleLevel[];
  totalCapitalRequired: number;
  breakEvenPrice: number;
  profitAtTarget: number;
  riskAssessment: string;
}

export function calculateMartingale(
  currentPrice: number,
  drawdownPercent: number,
  positionSizes: number[],
  targetProfitPercent: number,
  availableCapital?: number
): MartingaleResult {
  const levels: MartingaleLevel[] = [];
  let cumulativeCapital = 0;
  let cumulativeSize = 0;
  let totalPrice = 0;
  
  for (let i = 0; i < positionSizes.length; i++) {
    // Compound (multiplicative) price drop: each level drops by drawdownPercent from previous level
    const entryPrice = currentPrice * Math.pow(1 - drawdownPercent / 100, i);
    const positionSize = positionSizes[i];
    const capitalRequired = entryPrice * positionSize;
    
    cumulativeCapital += capitalRequired;
    cumulativeSize += positionSize;
    totalPrice += entryPrice * positionSize;
    
    const averagePrice = totalPrice / cumulativeSize;
    
    levels.push({
      level: i + 1,
      price: Math.round(entryPrice * 100) / 100,
      positionSize: positionSize,
      cumulativeSize: Math.round(cumulativeSize * 100) / 100,
      cumulativeCapital: Math.round(cumulativeCapital * 100) / 100,
      averagePrice: Math.round(averagePrice * 100) / 100,
    });
  }
  
  const averagePrice = totalPrice / cumulativeSize;
  const breakEvenPrice = Math.round(averagePrice * 100) / 100;
  const targetPrice = averagePrice * (1 + targetProfitPercent / 100);
  const profitAtTarget = (targetPrice - averagePrice) * cumulativeSize;
  
  // Risk assessment based on capital ratio if availableCapital provided, otherwise absolute
  let riskAssessment = '';
  if (availableCapital && availableCapital > 0) {
    const ratio = cumulativeCapital / availableCapital;
    if (ratio > 0.8) {
      riskAssessment = 'EXTREME RISK: Over 80% of your capital is required. Reduce position sizes immediately.';
    } else if (ratio > 0.5) {
      riskAssessment = 'HIGH RISK: Over 50% of your capital is required. Consider reducing position sizes.';
    } else if (ratio > 0.2) {
      riskAssessment = 'MODERATE RISK: 20–50% of your capital is required. Monitor closely.';
    } else {
      riskAssessment = 'LOW RISK: Less than 20% of your capital is required. Manageable exposure.';
    }
  } else {
    if (cumulativeCapital > 100000) {
      riskAssessment = 'EXTREME RISK: Total capital required is very high. Proceed with extreme caution.';
    } else if (cumulativeCapital > 50000) {
      riskAssessment = 'HIGH RISK: Significant capital required. Consider reducing position sizes.';
    } else if (cumulativeCapital > 10000) {
      riskAssessment = 'MODERATE RISK: Reasonable capital requirement. Monitor closely.';
    } else {
      riskAssessment = 'LOW RISK: Capital requirement is manageable.';
    }
  }
  
  return {
    levels,
    totalCapitalRequired: Math.round(cumulativeCapital * 100) / 100,
    breakEvenPrice,
    profitAtTarget: Math.round(profitAtTarget * 100) / 100,
    riskAssessment,
  };
}

/**
 * VIP Integrated Strategy Calculator
 * Combines Kelly Criterion, Martingale, and Compound Interest
 */
export interface VIPStrategyResult {
  targetMonthlyReturn: number;
  recommendedKellyFraction: number;
  initialPositionSize: number;
  martingaleStrategy: MartingaleLevel[];
  compoundProjection: {
    month3: number;
    month6: number;
    month12: number;
  };
  summary: string;
}

export function calculateVIPStrategy(
  targetMonthlyReturn: number,
  winRate: number,
  profitRatio: number,
  lossRatio: number,
  initialCapital: number,
  drawdownPercent: number
): VIPStrategyResult {
  // Step 1: Calculate Kelly Criterion for optimal position sizing
  const kellyResult = calculateKellyCriterion(winRate, profitRatio, lossRatio);
  const recommendedKelly = kellyResult.halfKelly / 100; // Use half Kelly for safety
  
  // Step 2: Calculate initial position size to achieve target return
  const initialPositionSize = Math.round((recommendedKelly * initialCapital) * 100) / 100;
  
  // Step 3: Create Martingale strategy with scaled positions (compound drop)
  const positionSizes = [
    initialPositionSize * 0.01,
    initialPositionSize * 0.02,
    initialPositionSize * 0.03,
    initialPositionSize * 0.05,
  ];
  
  const martingaleResult = calculateMartingale(
    initialCapital,
    drawdownPercent,
    positionSizes,
    targetMonthlyReturn,
    initialCapital
  );
  
  // Step 4: Project compound growth based on target monthly return
  const compoundResult = calculateCompoundInterest(
    initialCapital,
    targetMonthlyReturn,
    0,
    12
  );
  
  const summary = `To achieve ${targetMonthlyReturn}% monthly return with ${winRate}% win rate:\n1. Use ${(recommendedKelly * 100).toFixed(2)}% of capital per trade (Half Kelly)\n2. Initial position: $${initialPositionSize.toLocaleString()}\n3. Scale positions down ${drawdownPercent}% per level to reduce risk\n4. Break-even price: $${martingaleResult.breakEvenPrice.toLocaleString()}\n5. Projected 12-month balance: $${compoundResult.finalAmount.toLocaleString()}`;
  
  return {
    targetMonthlyReturn,
    recommendedKellyFraction: Math.round(recommendedKelly * 10000) / 100,
    initialPositionSize,
    martingaleStrategy: martingaleResult.levels,
    compoundProjection: {
      month3: Math.round(compoundResult.monthlyData[2]?.balance || 0),
      month6: Math.round(compoundResult.monthlyData[5]?.balance || 0),
      month12: Math.round(compoundResult.monthlyData[11]?.balance || 0),
    },
    summary,
  };
}
