import { useState, useMemo } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft, Crown, TrendingUp, AlertCircle, Info } from 'lucide-react';
import { calculateKellyCriterion } from '@/lib/calculators';
import AdSense from '@/components/AdSense';
import SidebarAds from '@/components/SidebarAds';
import { EducationAccordion } from '@/components/EducationAccordion';



export default function VIPStrategy() {
  const [, setLocation] = useLocation();
  
  // Kelly Parameters
  const [targetMonthlyReturn, setTargetMonthlyReturn] = useState(10);
  const [winRate, setWinRate] = useState(55);
  const [profitRatio, setProfitRatio] = useState(2);
  const [lossRatio, setLossRatio] = useState(1);
  const [tradingCapital, setTradingCapital] = useState(10000);
  
  // Martingale Parameters
  const [currentAssetPrice, setCurrentAssetPrice] = useState(100);
  const [entryLevels, setEntryLevels] = useState(4);
  const [priceDropPercent, setPriceDropPercent] = useState(5);

  // Calculate Kelly Criterion
  const kellyResult = useMemo(() => {
    return calculateKellyCriterion(winRate, profitRatio, lossRatio);
  }, [winRate, profitRatio, lossRatio]);

  // Use Half Kelly for conservative approach
  const kellyFraction = kellyResult.halfKelly;
  const positionSizePercent = kellyFraction;

  // Calculate Martingale Entry Levels
  const martingaleData = useMemo(() => {
    const levels = [];
    const totalCapitalForStrategy = (tradingCapital * positionSizePercent) / 100;
    const capitalPerLevel = totalCapitalForStrategy / entryLevels;
    
    let totalShares = 0;
    let totalInvested = 0;
    let sumPriceTimesShares = 0;

    for (let i = 0; i < entryLevels; i++) {
      const priceAtLevel = currentAssetPrice * (1 - (priceDropPercent / 100) * i);
      const sharesAtLevel = capitalPerLevel / priceAtLevel;
      const investmentAtLevel = capitalPerLevel;

      levels.push({
        level: i + 1,
        price: priceAtLevel,
        shares: sharesAtLevel,
        investment: investmentAtLevel,
        percentOfTotal: (investmentAtLevel / totalCapitalForStrategy) * 100,
      });

      totalShares += sharesAtLevel;
      totalInvested += investmentAtLevel;
      sumPriceTimesShares += priceAtLevel * sharesAtLevel;
    }

    const averagePrice = sumPriceTimesShares / totalShares;

    return {
      levels,
      totalShares,
      totalInvested,
      averagePrice,
      breakEvenPrice: averagePrice,
    };
  }, [tradingCapital, positionSizePercent, currentAssetPrice, entryLevels, priceDropPercent]);

  // 12-month projection
  const monthlyProjection = useMemo(() => {
    const projections = [];
    let balance = tradingCapital;
    const monthlyGrowthRate = targetMonthlyReturn / 100;

    for (let month = 1; month <= 12; month++) {
      balance = balance * (1 + monthlyGrowthRate);
      projections.push({
        month,
        balance,
        profit: balance - tradingCapital,
      });
    }

    return projections;
  }, [tradingCapital, targetMonthlyReturn]);

  // Chrome translation safe number parser
  const parseNum = (val: string) => {
    const n = parseFloat(val.replace(/[^0-9.\-]/g, ''));
    return isNaN(n) ? 0 : n;
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-primary/20 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center gap-4">
          <button
            onClick={() => setLocation('/')}
            className="p-2 hover:bg-primary/10 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gold" />
          </button>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-gold" />
              <h1 className="text-2xl font-bold text-foreground">VIP Integrated Strategy</h1>
            </div>
            <p className="text-xs text-muted-foreground">Kelly Criterion + Martingale Pyramid Combined</p>
          </div>
        </div>
      </header>

      {/* Top Banner Ad */}
      <div className="bg-card/50 py-4 border-b border-primary/20">
        <div className="container">
          <AdSense slot="1234567899" format="horizontal" responsive={true} />
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-12">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Sidebar Ads */}
          <div className="hidden lg:block">
            <SidebarAds />
          </div>

          {/* Left: Input Form */}
          <div className="lg:col-span-1">
            <div className="card-gold-glow p-6 sticky top-24 space-y-6">
              <div>
                <h2 className="text-xl font-bold mb-6 text-foreground">Strategy Configuration</h2>

                {/* Target Monthly Return */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-muted-foreground mb-2">
                    Target Monthly Return (%)
                  </label>
                  <input
                    type="number"
                    value={targetMonthlyReturn}
                    onChange={(e) => setTargetMonthlyReturn(parseNum(e.target.value))}
                    step="0.5"
                    className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Your monthly profit goal (e.g., 10% per month)</p>
                </div>

                {/* Win Rate */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-muted-foreground mb-2">
                    Win Rate (%)
                  </label>
                  <input
                    type="number"
                    value={winRate}
                    onChange={(e) => setWinRate(Math.max(0, Math.min(100, parseNum(e.target.value))))}
                    step="1"
                    className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Your historical win rate (0-100%)</p>
                </div>

                {/* Profit Ratio */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-muted-foreground mb-2">
                    Avg Profit per Win (%)
                  </label>
                  <input
                    type="number"
                    value={profitRatio}
                    onChange={(e) => setProfitRatio(Math.max(0.1, parseNum(e.target.value)))}
                    step="0.1"
                    className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Average profit when you win</p>
                </div>

                {/* Loss Ratio */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-muted-foreground mb-2">
                    Avg Loss per Loss (%)
                  </label>
                  <input
                    type="number"
                    value={lossRatio}
                    onChange={(e) => setLossRatio(Math.max(0.1, parseNum(e.target.value)))}
                    step="0.1"
                    className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Average loss when you lose</p>
                </div>

                {/* Trading Capital */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-muted-foreground mb-2">
                    Total Trading Capital
                  </label>
                  <input
                    type="number"
                    value={tradingCapital}
                    onChange={(e) => setTradingCapital(Math.max(0, parseNum(e.target.value)))}
                    className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Your total available trading capital</p>
                </div>
              </div>

              <div className="border-t border-primary/20 pt-6">
                <h3 className="text-lg font-bold mb-6 text-foreground">Martingale Parameters</h3>

                {/* Current Asset Price */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-muted-foreground mb-2">
                    Current Price per Unit
                  </label>
                  <input
                    type="number"
                    value={currentAssetPrice}
                    onChange={(e) => setCurrentAssetPrice(Math.max(0.01, parseNum(e.target.value)))}
                    step="0.01"
                    className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Current price of the stock / coin / asset</p>
                </div>

                {/* Entry Levels */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-muted-foreground mb-2">
                    Number of Entry Levels
                  </label>
                  <input
                    type="number"
                    value={entryLevels}
                    onChange={(e) => setEntryLevels(Math.max(1, Math.min(10, parseNum(e.target.value))))}
                    step="1"
                    className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                  />
                  <p className="text-xs text-muted-foreground mt-1">How many times to buy as price drops (1-10)</p>
                </div>

                {/* Price Drop Percent */}
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-muted-foreground mb-2">
                    Price Drop Between Entries (%)
                  </label>
                  <input
                    type="number"
                    value={priceDropPercent}
                    onChange={(e) => setPriceDropPercent(Math.max(0.1, parseNum(e.target.value)))}
                    step="0.5"
                    className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Buy again when price drops this much (e.g., 5% = buy at -5%, -10%, -15%)</p>
                </div>
              </div>
            </div>
          </div>

          {/* Center: Entry Levels Detail */}
          <div className="lg:col-span-1">
            <div className="card-gold-glow p-6 sticky top-24">
              <h3 className="text-lg font-bold mb-4 text-foreground">Entry Levels</h3>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {martingaleData.levels.map((level) => (
                  <div key={level.level} className="bg-primary/10 p-3 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-xs font-bold text-gold">Level {level.level}</span>
                      <span className="text-xs text-accent">{level.price.toFixed(2)}</span>
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Quantity:</span>
                        <span className="font-mono text-foreground">{level.shares.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Capital:</span>
                        <span className="font-mono text-gold">{level.investment.toFixed(0)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">% of Total:</span>
                        <span className="font-mono text-accent">{level.percentOfTotal.toFixed(1)}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Totals */}
              <div className="mt-4 pt-4 border-t border-primary/20 space-y-2">
                <div className="flex justify-between">
                  <span className="text-xs text-muted-foreground">Total Quantity:</span>
                  <span className="text-sm font-bold text-gold font-mono">{martingaleData.totalShares.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-muted-foreground">Total Capital:</span>
                  <span className="text-sm font-bold text-gold font-mono">{martingaleData.totalInvested.toFixed(0)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-muted-foreground">Avg Entry Price:</span>
                  <span className="text-sm font-bold text-accent font-mono">{martingaleData.averagePrice.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Results & Projections */}
          <div className="lg:col-span-2 space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-2 gap-4">
              {/* Kelly Fraction */}
              <div className="card-gold-glow p-5">
                <p className="text-xs text-muted-foreground mb-2">Kelly Fraction (Half)</p>
                <p className="text-2xl font-bold text-gold font-mono">{kellyFraction.toFixed(2)}%</p>
                <p className="text-xs text-accent mt-2">Position size per trade</p>
              </div>

              {/* Break-Even Price */}
              <div className="card-gold-glow p-5">
                <p className="text-xs text-muted-foreground mb-2">Break-Even Price</p>
                <p className="text-2xl font-bold text-gold font-mono">{martingaleData.breakEvenPrice.toFixed(2)}</p>
                <p className="text-xs text-accent mt-2">
                  {martingaleData.breakEvenPrice > currentAssetPrice
                    ? `↑ ${((martingaleData.breakEvenPrice / currentAssetPrice - 1) * 100).toFixed(1)}% above current`
                    : `↓ ${((1 - martingaleData.breakEvenPrice / currentAssetPrice) * 100).toFixed(1)}% below current`}
                </p>
              </div>

              {/* Total Capital Required */}
              <div className="card-gold-glow p-5">
                <p className="text-xs text-muted-foreground mb-2">Total Capital Required</p>
                <p className="text-2xl font-bold text-gold font-mono">{martingaleData.totalInvested.toFixed(0)}</p>
                <p className="text-xs text-accent mt-2">For all {entryLevels} entry levels</p>
              </div>

              {/* Available Capital */}
              <div className="card-gold-glow p-5">
                <p className="text-xs text-muted-foreground mb-2">Available Capital</p>
                <p className="text-2xl font-bold text-gold font-mono">{(tradingCapital - martingaleData.totalInvested).toFixed(0)}</p>
                <p className="text-xs text-accent mt-2">Remaining after strategy</p>
              </div>
            </div>

            {/* Strategy Guide */}
            <div className="card-gold-glow p-5 border-l-4 border-gold">
              <div className="flex gap-2 mb-3">
                <Info className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                <h4 className="text-sm font-bold text-foreground">How This Strategy Works</h4>
              </div>
              <div className="space-y-2 text-xs text-muted-foreground">
                <p>
                  <strong className="text-foreground">1. First Entry:</strong> Buy {martingaleData.levels[0].shares.toFixed(2)} units at {currentAssetPrice.toFixed(2)}
                </p>
                <p>
                  <strong className="text-foreground">2. If Price Drops {priceDropPercent}%:</strong> Buy {martingaleData.levels[1]?.shares.toFixed(2)} more units at {martingaleData.levels[1]?.price.toFixed(2)}
                </p>
                <p>
                  <strong className="text-foreground">3. Continue:</strong> Repeat for all {entryLevels} levels
                </p>
                <p>
                  <strong className="text-foreground">4. Exit:</strong> When price reaches {martingaleData.breakEvenPrice.toFixed(2)} (break-even), sell all units
                </p>
              </div>
            </div>

            {/* 12-Month Projection */}
            <div className="card-gold-glow p-5">
              <h3 className="text-sm font-bold mb-3 text-foreground">12-Month Profit Projection</h3>
              <div className="space-y-2 text-xs max-h-48 overflow-y-auto">
                {monthlyProjection.map((proj) => (
                  <div key={proj.month} className="flex justify-between p-2 bg-primary/10 rounded">
                    <span className="text-muted-foreground">Month {proj.month}</span>
                    <div className="text-right">
                      <div className="font-mono font-semibold text-foreground">{proj.balance.toLocaleString('en-US', { maximumFractionDigits: 0 })}</div>
                      <div className="text-accent">+{proj.profit.toLocaleString('en-US', { maximumFractionDigits: 0 })}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Strategy Notes */}
            <div className="card-gold-glow p-5 border-l-4 border-gold">
              <div className="flex gap-2">
                <AlertCircle className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-semibold text-foreground mb-1">Important Notes</p>
                  <p className="text-xs text-muted-foreground">
                    This strategy requires sufficient capital to execute all {entryLevels} levels. If price continues falling beyond your capital limit, you cannot execute all entries. Use this as a guideline and adjust parameters based on your risk tolerance. Always consult with a financial advisor before trading.
                  </p>
                </div>
              </div>
            </div>

            {/* Education Section */}
            <div className="card-gold-glow p-6">
              <h3 className="text-lg font-bold mb-4 text-foreground">📖 Learn About VIP Integrated Strategy</h3>
              <EducationAccordion sections={[
                {
                  title: '📚 What is VIP Integrated Strategy?',
                  content: `VIP (Value Investing with Position sizing) combines Kelly Criterion for optimal position sizing with Martingale pyramid entry strategy. It automatically calculates the perfect entry levels and quantities based on your trading statistics, creating a complete integrated trading system.`,
                },
                {
                  title: '🎯 Why Use VIP Strategy?',
                  content: `• Optimal Sizing: Kelly Criterion ensures mathematically optimal position size
• Pyramid Entries: Martingale entries reduce average price
• Integrated System: Both strategies work together seamlessly
• Automated Calculations: Removes guesswork from trading
• Risk Management: Combines two proven risk management techniques
• Professional Grade: Used by institutional traders`,
                },
                {
                  title: '✅ Advantages',
                  content: `1. Complete System: Combines position sizing and entry strategy
2. Mathematically Optimized: Kelly + Martingale proven methods
3. Reduced Average Price: Pyramid entries lower your cost basis
4. Risk Controlled: Kelly sizing prevents over-leverage
5. Flexible: Adjust all parameters to your needs
6. Scalable: Works with any trading account size`,
                },
                {
                  title: '⚠️ Disadvantages',
                  content: `1. Complexity: Requires understanding both strategies
2. Capital Intensive: Needs significant capital for all levels
3. Execution Risk: Must follow all levels exactly`,
                },
                {
                  title: '🚨 Risk Factors',
                  content: `• Capital Depletion: May run out of capital before price recovers
• Estimation Error: Inaccurate win rates affect Kelly sizing
• Market Gaps: Price can gap down past multiple levels
• Psychological: Requires discipline to follow plan during losses
• Liquidation: Forced to sell at loss if capital exhausted`,
                },
                {
                  title: '💡 Tips & Best Practices',
                  content: `1. Start Small: Test with small capital first
2. Track Statistics: Keep accurate records of win rate
3. Backtest: Verify strategy works on historical data
4. Adjust Gradually: Don't change all parameters at once
5. Monitor Levels: Watch each entry level carefully
6. Set Limits: Define maximum loss before starting
7. Review Monthly: Recalculate Kelly sizing monthly
8. Use Half Kelly: More conservative than Full Kelly`,
                },
                {
                  title: '📖 How to Use This Calculator',
                  content: `Target Monthly Return (%): Your desired monthly profit target

Win Rate (%): Your historical percentage of winning trades

Average Profit per Trade (%): Average gain on winning trades

Average Loss per Trade (%): Average loss on losing trades

Total Trading Capital: Your total account size

Current Asset Price: Entry price of the asset

Entry Levels: Number of pyramid entry levels (2-10 recommended)

Price Drop Between Entries (%): Price drop before next entry

Results:
• Kelly Fraction: Optimal position size percentage
• Martingale Levels: Each level's price and quantity
• Average Entry Price: Weighted average of all entries
• Break-Even Price: Price needed to recover capital
• 12-Month Projection: Expected account growth`,
                },
              ]} />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Banner Ad */}
      <div className="bg-card/50 py-4 border-t border-primary/20 mt-12">
        <div className="container">
          <AdSense slot="1234567900" format="horizontal" responsive={true} />
        </div>
      </div>
    </div>
  );
}
