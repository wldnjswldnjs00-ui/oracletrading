import { useState, useMemo } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft } from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { calculateCompoundInterest } from '@/lib/calculators';
import AdSense from '@/components/AdSense';
import SidebarAds from '@/components/SidebarAds';
import { EducationAccordion } from '@/components/EducationAccordion';

export default function CompoundCalculator() {
  const [, setLocation] = useLocation();
  const [initialCapital, setInitialCapital] = useState(10000);
  const [monthlyReturn, setMonthlyReturn] = useState(5);
  const [months, setMonths] = useState(12);
  const [timeUnit, setTimeUnit] = useState<'days' | 'months' | 'years'>('months');

  const result = useMemo(() => {
    let totalMonths: number;
    if (timeUnit === 'years') {
      totalMonths = Math.max(1, months * 12);
    } else if (timeUnit === 'days') {
      totalMonths = Math.max(1, Math.round(months / 30));
    } else {
      totalMonths = Math.max(1, months);
    }
    return calculateCompoundInterest(initialCapital, monthlyReturn, 0, totalMonths);
  }, [initialCapital, monthlyReturn, months, timeUnit]);

  const displayData = useMemo(() => {
    if (timeUnit === 'days') {
      const dailyRate = monthlyReturn / 100 / 30;
      const data = [];
      let balance = initialCapital;
      for (let d = 1; d <= Math.max(1, months); d++) {
        balance = balance * (1 + dailyRate);
        data.push({
          month: d,
          balance: Math.round(balance * 100) / 100,
          invested: initialCapital,
          profit: Math.round((balance - initialCapital) * 100) / 100,
        });
      }
      return {
        finalAmount: data[data.length - 1]?.balance ?? initialCapital,
        totalInvested: initialCapital,
        totalProfit: data[data.length - 1]?.profit ?? 0,
        monthlyData: data,
      };
    }
    return result;
  }, [timeUnit, months, initialCapital, monthlyReturn, result]);

  const handleTimeUnitChange = (unit: 'days' | 'months' | 'years') => {
    setTimeUnit(unit);
    if (unit === 'years' && months > 120) {
      setMonths(10);
    } else if (unit === 'days' && months > 365) {
      setMonths(365);
    }
  };

  const parseNum = (val: string) => {
    const n = parseFloat(val.replace(/[^0-9.\-]/g, ''));
    return isNaN(n) ? 0 : n;
  };

  const periodLabel = timeUnit === 'days' ? 'days' : timeUnit === 'years' ? 'years' : 'months';
  const rowLabel = timeUnit === 'days' ? 'Day' : timeUnit === 'years' ? 'Year' : 'Month';

  const educationSections = [
    {
      title: '📚 What is Compound Interest?',
      content: `Compound interest is the process of earning returns on both your initial investment and the accumulated interest from previous periods. It's often called "interest on interest" and is the foundation of wealth building.

Formula: A = P(1 + r)^n
Where: P = Principal, r = Rate per period, n = Number of periods`,
    },
    {
      title: '🎯 Why Use This Calculator?',
      content: `• Visualize long-term wealth growth with different return rates
• Compare different time horizons (days, months, years)
• Understand the power of consistent returns over time
• Plan your investment strategy with realistic projections
• See exactly how much profit you'll earn at each period`,
    },
    {
      title: '✅ Advantages',
      content: `1. Exponential Growth: Your money grows faster as time goes on
2. Passive Income: Earn returns on returns automatically
3. Time Value: Starting early makes a huge difference
4. Predictable: Mathematical formula ensures accuracy
5. Flexible: Works with any return rate and time period
6. Tax Efficiency: Long-term investments often have tax benefits`,
    },
    {
      title: '⚠️ Disadvantages',
      content: `1. Requires Patience: Significant growth takes considerable time
2. Market Risk: Actual returns may vary from projections
3. Inflation Impact: Real purchasing power may be lower than expected`,
    },
    {
      title: '🚨 Risk Factors',
      content: `• Market Volatility: Returns fluctuate, especially short-term
• Inflation Risk: Purchasing power decreases over time
• Liquidity Risk: Funds may be locked in long-term investments
• Opportunity Cost: Money tied up can't be used elsewhere`,
    },
    {
      title: '💡 Tips & Best Practices',
      content: `1. Start Early: Time is your biggest advantage in compound growth
2. Be Consistent: Regular contributions amplify compound effects
3. Reinvest Returns: Don't withdraw profits; let them compound
4. Diversify: Spread investments to reduce risk
5. Review Regularly: Adjust strategy based on actual performance
6. Use Different Scenarios: Test various return rates to be realistic`,
    },
    {
      title: '📖 How to Use This Calculator',
      content: `Starting Amount: Your initial investment capital

Monthly Return (%): Expected monthly return percentage
• 1-2% for conservative investments
• 3-5% for moderate growth
• 5%+ for aggressive strategies

Investment Duration: Choose time unit (Day/Month/Year)
• Day: Short-term daily compounding
• Month: Standard monthly calculations
• Year: Long-term annual projections

Results:
• Final Balance: Total amount after all periods
• Total Gain: Pure profit earned
• Return on Investment: Percentage gain relative to initial investment
• Gain %: Period-to-period return percentage
• Compound %: Cumulative return from start`,
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-primary/20 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center gap-4">
          <button
            onClick={() => setLocation('/')}
            className="p-2 hover:bg-primary/10 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gold" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Compound Interest Calculator</h1>
            <p className="text-sm text-muted-foreground">Project your wealth growth with compound returns</p>
          </div>
        </div>
      </header>

      {/* Top Banner Ad */}
      <div className="bg-card/50 py-4 border-b border-primary/20">
        <div className="container">
          <AdSense slot="1234567893" format="horizontal" responsive={true} />
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Ads */}
          <div className="hidden lg:block">
            <SidebarAds />
          </div>

          {/* Left: Input Form */}
          <div className="lg:col-span-1">
            <div className="card-gold-glow p-6 sticky top-24">
              <h2 className="text-xl font-bold mb-6 text-foreground">Investment Parameters</h2>

              {/* Initial Capital */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-muted-foreground mb-2">
                  Starting Amount
                </label>
                <input
                  type="number"
                  value={initialCapital}
                  onChange={(e) => setInitialCapital(Math.max(0, parseNum(e.target.value)))}
                  className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                />
                <p className="text-xs text-muted-foreground mt-1">Your initial investment amount</p>
              </div>

              {/* Monthly Return Rate */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-muted-foreground mb-2">
                  Monthly Return (%)
                </label>
                <input
                  type="number"
                  value={monthlyReturn}
                  onChange={(e) => setMonthlyReturn(parseNum(e.target.value))}
                  step="0.1"
                  className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                />
                <p className="text-xs text-muted-foreground mt-1">Expected monthly return percentage</p>
              </div>

              {/* Time Period */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-muted-foreground mb-2">
                  Investment Duration
                </label>

                <div className="flex flex-wrap gap-2 mb-2">
                  <input
                    type="number"
                    value={months}
                    onChange={(e) => setMonths(Math.max(1, parseNum(e.target.value)))}
                    className="w-20 px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                  />
                  <div className="flex gap-1">
                    <button
                      onClick={() => handleTimeUnitChange('days')}
                      className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                        timeUnit === 'days'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-card border border-primary/20 text-muted-foreground hover:border-primary/50'
                      }`}
                    >
                      Day
                    </button>
                    <button
                      onClick={() => handleTimeUnitChange('months')}
                      className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                        timeUnit === 'months'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-card border border-primary/20 text-muted-foreground hover:border-primary/50'
                      }`}
                    >
                      Month
                    </button>
                    <button
                      onClick={() => handleTimeUnitChange('years')}
                      className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                        timeUnit === 'years'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-card border border-primary/20 text-muted-foreground hover:border-primary/50'
                      }`}
                    >
                      Year
                    </button>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  {timeUnit === 'days'
                    ? `${months} days`
                    : timeUnit === 'years'
                    ? `${months} years (${months * 12} months)`
                    : `${months} months`}
                </p>
              </div>
            </div>
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-2 space-y-6">
            {/* Key Metrics - 4 Cards */}
            <div className="grid grid-cols-2 gap-4">
              <div className="card-gold-glow p-5">
                <p className="text-xs text-muted-foreground mb-2">Final Balance</p>
                <p className="text-2xl font-bold text-gold font-mono">
                  {displayData.finalAmount.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                </p>
                <p className="text-xs text-accent mt-2">After {months} {periodLabel}</p>
              </div>

              <div className="card-gold-glow p-5">
                <p className="text-xs text-muted-foreground mb-2">Total Gain</p>
                <p className="text-2xl font-bold text-gold font-mono">
                  {displayData.totalProfit.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                </p>
                <p className="text-xs text-accent mt-2">Pure profit earned</p>
              </div>

              <div className="card-gold-glow p-5">
                <p className="text-xs text-muted-foreground mb-2">Initial Investment</p>
                <p className="text-2xl font-bold text-accent font-mono">
                  {displayData.totalInvested.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                </p>
                <p className="text-xs text-muted-foreground mt-2">Your starting capital</p>
              </div>

              <div className="card-gold-glow p-5">
                <p className="text-xs text-muted-foreground mb-2">Return on Investment</p>
                <p className="text-2xl font-bold text-accent font-mono">
                  {displayData.totalInvested > 0
                    ? ((displayData.totalProfit / displayData.totalInvested) * 100).toFixed(1)
                    : '0.0'}%
                </p>
                <p className="text-xs text-muted-foreground mt-2">Total return percentage</p>
              </div>
            </div>

            {/* Growth Chart */}
            <div className="card-gold-glow p-6">
              <h3 className="text-lg font-bold mb-4 text-foreground">Growth Projection</h3>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={displayData.monthlyData}>
                  <defs>
                    <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="rgba(255, 215, 0, 0.8)" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="rgba(255, 215, 0, 0)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 215, 0, 0.1)" />
                  <XAxis
                    dataKey="month"
                    stroke="rgba(255, 215, 0, 0.5)"
                    tick={{ fontSize: 11 }}
                  />
                  <YAxis
                    stroke="rgba(255, 215, 0, 0.5)"
                    tick={{ fontSize: 11 }}
                    tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(10, 14, 39, 0.95)',
                      border: '1px solid rgba(255, 215, 0, 0.3)',
                      borderRadius: '8px',
                      color: '#F5F5F5',
                    }}
                    formatter={(value: number) => [
                      value.toLocaleString('en-US', { maximumFractionDigits: 0 }),
                      'Balance',
                    ]}
                  />
                  <Area
                    type="monotone"
                    dataKey="balance"
                    stroke="rgba(255, 215, 0, 1)"
                    fillOpacity={1}
                    fill="url(#colorBalance)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Breakdown Table */}
            <div className="card-gold-glow p-6">
              <h3 className="text-lg font-bold mb-4 text-foreground">
                {timeUnit === 'days' ? 'Day-by-Day Breakdown' : timeUnit === 'years' ? 'Year-by-Year Breakdown' : 'Month-by-Month Breakdown'}
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-primary/20">
                      <th className="text-left py-2 px-2 text-muted-foreground font-semibold">{rowLabel}</th>
                      <th className="text-right py-2 px-2 text-muted-foreground font-semibold">Balance</th>
                      <th className="text-right py-2 px-2 text-muted-foreground font-semibold">Gain</th>
                      <th className="text-right py-2 px-2 text-muted-foreground font-semibold">Gain %</th>
                      <th className="text-right py-2 px-2 text-muted-foreground font-semibold">Compound %</th>
                    </tr>
                  </thead>
                  <tbody>
                    {displayData.monthlyData.map((row, idx) => {
                      const prevBalance = idx === 0 ? initialCapital : displayData.monthlyData[idx - 1].balance;
                      const periodGainPercent = prevBalance > 0 ? ((row.balance - prevBalance) / prevBalance * 100) : 0;
                      const totalCompoundPercent = initialCapital > 0 ? ((row.balance - initialCapital) / initialCapital * 100) : 0;
                      return (
                        <tr key={row.month} className="border-b border-primary/10 hover:bg-primary/5">
                          <td className="py-2 px-2 text-foreground font-semibold">{rowLabel} {row.month}</td>
                          <td className="text-right py-2 px-2 text-gold font-mono font-semibold">
                            {row.balance.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                          </td>
                          <td className="text-right py-2 px-2 text-accent font-mono">
                            {row.profit.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                          </td>
                          <td className="text-right py-2 px-2 text-accent font-mono text-xs">
                            {periodGainPercent.toFixed(2)}%
                          </td>
                          <td className="text-right py-2 px-2 text-gold font-mono text-xs">
                            {totalCompoundPercent.toFixed(2)}%
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Education Section */}
            <div className="card-gold-glow p-6">
              <h3 className="text-lg font-bold mb-4 text-foreground">📖 Learn About Compound Interest</h3>
              <EducationAccordion sections={educationSections} />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Banner Ad */}
      <div className="bg-card/50 py-4 border-t border-primary/20 mt-12">
        <div className="container">
          <AdSense slot="1234567894" format="horizontal" responsive={true} />
        </div>
      </div>
    </div>
  );
}
