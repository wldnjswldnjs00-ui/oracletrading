import { useState, useMemo } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft, AlertCircle } from 'lucide-react';
import { calculateKellyCriterion } from '@/lib/calculators';
import AdSense from '@/components/AdSense';
import SidebarAds from '@/components/SidebarAds';
import { EducationAccordion } from '@/components/EducationAccordion';



export default function KellyCalculator() {
  const [, setLocation] = useLocation();
  
  const [winRate, setWinRate] = useState(55);
  const [profitRatio, setProfitRatio] = useState(2);
  const [lossRatio, setLossRatio] = useState(1);
  const [seedCapital, setSeedCapital] = useState(10000);

  const result = useMemo(() => {
    return calculateKellyCriterion(winRate, profitRatio, lossRatio);
  }, [winRate, profitRatio, lossRatio]);

  const parseNum = (val: string) => {
    const n = parseFloat(val.replace(/[^0-9.\-]/g, ''));
    return isNaN(n) ? 0 : n;
  };

  const fullKellyAmount = useMemo(
    () => (seedCapital * result.fullKelly) / 100,
    [seedCapital, result.fullKelly]
  );
  const halfKellyAmount = useMemo(
    () => (seedCapital * result.halfKelly) / 100,
    [seedCapital, result.halfKelly]
  );
  const quarterKellyAmount = useMemo(
    () => (seedCapital * result.quarterKelly) / 100,
    [seedCapital, result.quarterKelly]
  );

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-primary/20 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center gap-4">
          <button
            onClick={() => setLocation('/')}
            className="p-2 hover:bg-primary/10 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gold" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Kelly Criterion Calculator</h1>
            <p className="text-sm text-muted-foreground">Determine optimal position sizing for your trading strategy</p>
          </div>
        </div>
      </header>

      {/* Top Banner Ad */}
      <div className="bg-card/50 py-4 border-b border-primary/20">
        <div className="container">
          <AdSense slot="1234567895" format="horizontal" responsive={true} />
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Ads */}
          <div className="hidden lg:block">
            <SidebarAds />
          </div>
          {/* Left: Input Form */}
          <div className="lg:col-span-1">
            <div className="card-gold-glow p-6 sticky top-24">
              <h2 className="text-xl font-bold mb-6 text-foreground">Strategy Parameters</h2>

              {/* Win Rate */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-muted-foreground mb-2">
                  Win Rate (%)
                </label>
                <input
                  type="number"
                  value={winRate}
                  onChange={(e) => setWinRate(parseNum(e.target.value))}
                  step="0.1"
                  className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                />
                <p className="text-xs text-muted-foreground mt-1">Your historical win rate percentage</p>
              </div>

              {/* Profit Ratio */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-muted-foreground mb-2">
                  Average Win Profit (%)
                </label>
                <input
                  type="number"
                  value={profitRatio}
                  onChange={(e) => setProfitRatio(parseNum(e.target.value))}
                  step="0.1"
                  className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                />
                <p className="text-xs text-muted-foreground mt-1">Average profit percentage per winning trade</p>
              </div>

              {/* Loss Ratio */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-muted-foreground mb-2">
                  Average Loss per Trade (%)
                </label>
                <input
                  type="number"
                  value={lossRatio}
                  onChange={(e) => setLossRatio(parseNum(e.target.value))}
                  step="0.1"
                  className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                />
                <p className="text-xs text-muted-foreground mt-1">Average loss percentage per losing trade</p>
              </div>

              {/* Seed Capital */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-muted-foreground mb-2">
                  Total Trading Capital
                </label>
                <input
                  type="number"
                  value={seedCapital}
                  onChange={(e) => setSeedCapital(Math.max(0, parseNum(e.target.value)))}
                  className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                />
                <p className="text-xs text-muted-foreground mt-1">Your total trading capital available</p>
              </div>

              {/* Risk-Reward Ratio */}
              <div className="p-3 bg-primary/10 rounded-lg border border-primary/20 mb-6">
                <p className="text-xs text-muted-foreground mb-1">Risk-Reward Ratio</p>
                <p className="text-xl font-bold text-gold font-mono">
                  1 : {(profitRatio / lossRatio).toFixed(2)}
                </p>
              </div>
            </div>
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-2 space-y-6">
            {/* Kelly Results */}
            <div className="space-y-4">
              {/* Full Kelly */}
              <div className="card-gold-glow p-5">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Full Kelly Fraction</p>
                    <p className="text-2xl font-bold text-gold font-mono" data-value={result.fullKelly.toFixed(2)}>
                      {result.fullKelly.toFixed(2)}%
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground mb-1">Position Size</p>
                    <p className="text-xl font-bold text-accent font-mono" data-amount={fullKellyAmount}>
                      {fullKellyAmount.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                    </p>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">Aggressive - Maximum growth potential</p>
              </div>

              {/* Half Kelly */}
              <div className="card-gold-glow p-5">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Half Kelly (Conservative)</p>
                    <p className="text-2xl font-bold text-gold font-mono" data-value={result.halfKelly.toFixed(2)}>
                      {result.halfKelly.toFixed(2)}%
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground mb-1">Position Size</p>
                    <p className="text-xl font-bold text-accent font-mono" data-amount={halfKellyAmount}>
                      {halfKellyAmount.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                    </p>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">Balanced - Recommended for most traders</p>
              </div>

              {/* Quarter Kelly */}
              <div className="card-gold-glow p-5">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Quarter Kelly (Very Conservative)</p>
                    <p className="text-2xl font-bold text-gold font-mono" data-value={result.quarterKelly.toFixed(2)}>
                      {result.quarterKelly.toFixed(2)}%
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground mb-1">Position Size</p>
                    <p className="text-xl font-bold text-accent font-mono" data-amount={quarterKellyAmount}>
                      {quarterKellyAmount.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                    </p>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">Safe - Minimizes drawdown risk</p>
              </div>
            </div>

            {/* Recommendation */}
            <div className="card-gold-glow p-5 border-l-4 border-gold">
              <div className="flex gap-3">
                <AlertCircle className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-semibold text-foreground mb-1">Recommendation</p>
                  <p className="text-xs text-muted-foreground">
                    Start with Half Kelly for balanced growth and risk management. Adjust based on your comfort level and market conditions.
                  </p>
                </div>
              </div>
            </div>

            {/* Summary */}
            <div className="card-gold-glow p-5">
              <h3 className="text-sm font-bold mb-3 text-foreground">Summary</h3>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total Capital:</span>
                  <span className="text-gold font-mono font-semibold">{seedCapital.toLocaleString('en-US')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Win Rate:</span>
                  <span className="text-accent font-mono">{winRate.toFixed(1)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Risk-Reward:</span>
                  <span className="text-accent font-mono">1:{(profitRatio / lossRatio).toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Education Section */}
            <div className="card-gold-glow p-6">
              <h3 className="text-lg font-bold mb-4 text-foreground">📖 Learn About Kelly Criterion</h3>
              <EducationAccordion sections={[
                {
                  title: '📚 What is Kelly Criterion?',
                  content: `The Kelly Criterion is a mathematical formula that determines the optimal position size for a given trade based on your win rate and risk-reward ratio. It maximizes long-term wealth growth while minimizing bankruptcy risk.

Formula: f* = (bp - q) / b
Where: b = Profit/Loss ratio, p = Win probability, q = Loss probability`,
                },
                {
                  title: '🎯 Why Use Kelly Criterion?',
                  content: `• Optimal Position Sizing: Determines exact percentage to risk per trade
• Maximize Growth: Mathematically proven to maximize long-term returns
• Minimize Risk: Prevents over-leveraging and catastrophic losses
• Objective Decision Making: Remove emotions from position sizing
• Bankroll Management: Protects your trading capital`,
                },
                {
                  title: '✅ Advantages',
                  content: `1. Mathematically Optimal: Proven to maximize long-term wealth
2. Risk Management: Automatically adjusts for your win rate
3. Scalable: Works for any trading strategy or market
4. Prevents Ruin: Reduces probability of account bankruptcy
5. Objective: Removes emotional decision-making
6. Adaptable: Recalculate as your strategy improves`,
                },
                {
                  title: '⚠️ Disadvantages',
                  content: `1. Requires Accurate Data: Needs reliable win rate and risk-reward stats
2. Volatility: Full Kelly can cause large drawdowns
3. Complexity: May be confusing for beginners`,
                },
                {
                  title: '🚨 Risk Factors',
                  content: `• Over-leveraging: Full Kelly can lead to 20-30% drawdowns
• Estimation Error: Inaccurate win rates destroy the strategy
• Market Changes: Historical stats may not predict future performance
• Psychological Pressure: Large position sizes can cause emotional trading`,
                },
                {
                  title: '💡 Tips & Best Practices',
                  content: `1. Start Conservative: Use Quarter or Half Kelly, not Full Kelly
2. Track Accurately: Keep detailed records of all trades
3. Adjust Regularly: Recalculate as your statistics improve
4. Test First: Backtest your strategy before live trading
5. Use Half Kelly: Better balance of growth and comfort
6. Combine Strategies: Use Kelly with other risk management tools`,
                },
                {
                  title: '📖 How to Use This Calculator',
                  content: `Win Rate (%): Your historical winning trade percentage
• 50% = Break-even strategy
• 55%+ = Profitable strategy
• 60%+ = Strong strategy

Average Profit per Trade (%): Average gain on winning trades
• 2% = Conservative profit target
• 5% = Moderate profit target
• 10%+ = Aggressive profit target

Average Loss per Trade (%): Average loss on losing trades
• Should match your stop-loss percentage
• Typically 1-2% per trade

Total Trading Capital: Your total account size

Results:
• Full Kelly: Aggressive sizing (maximum growth, high volatility)
• Half Kelly: Balanced sizing (recommended for most traders)
• Quarter Kelly: Conservative sizing (low volatility, slower growth)
• Position Size: Exact dollar amount to risk per trade`,
                },
              ]} />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Banner Ad */}
      <div className="bg-card/50 py-4 border-t border-primary/20 mt-12">
        <div className="container">
          <AdSense slot="1234567896" format="horizontal" responsive={true} />
        </div>
      </div>
    </div>
  );
}
