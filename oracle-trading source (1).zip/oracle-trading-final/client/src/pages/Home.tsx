import { useState } from 'react';
import { useLocation } from 'wouter';
import { ChevronRight, TrendingUp, Zap, GitBranch, Crown } from 'lucide-react';
import AdSense from '@/components/AdSense';

/**
 * Trading Oracle - Home Page
 * 
 * Design Philosophy: Luxury Financial Dashboard
 * - Deep Black (#0A0E27) background with Bright Gold (#FFD700) accents
 * - Playfair Display (serif) for headlines, IBM Plex Sans for body
 * - Asymmetric card layout with gold glow effects
 * - Smooth animations and premium interactions
 */

interface MenuCard {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  path: string;
  color: string;
  isVip?: boolean;
}

const menuCards: MenuCard[] = [
  {
    id: 'compound',
    title: 'Compound Interest',
    description: 'Calculate asset growth with regular investments and compound returns over time.',
    icon: <TrendingUp className="w-8 h-8" />,
    path: '/compound-calculator',
    color: 'from-amber-400 to-yellow-500',
  },
  {
    id: 'kelly',
    title: 'Kelly Criterion',
    description: 'Determine optimal position sizing based on your win rate and risk-reward ratio.',
    icon: <Zap className="w-8 h-8" />,
    path: '/kelly-calculator',
    color: 'from-yellow-400 to-orange-500',
  },
  {
    id: 'martingale',
    title: 'Martingale Simulator',
    description: 'Simulate pyramid entry strategy with custom drawdown levels and position scaling.',
    icon: <GitBranch className="w-8 h-8" />,
    path: '/martingale-simulator',
    color: 'from-orange-400 to-red-500',
  },
  {
    id: 'vip',
    title: 'VIP Strategy',
    description: 'Integrated solution combining Kelly, Martingale, and compound interest for optimal returns.',
    icon: <Crown className="w-8 h-8" />,
    path: '/vip-strategy',
    color: 'from-yellow-300 to-amber-500',
    isVip: true,
  },
];

export default function Home() {
  const [, setLocation] = useLocation();
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  const handleCardClick = (path: string) => {
    setLocation(path);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-primary/20 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">OT</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Oracle Trading</h1>
              <p className="text-xs text-muted-foreground">Investment Strategy Calculator</p>
            </div>
          </div>

        </div>
      </header>

      {/* Hero Section */}
      <section className="container py-16 md:py-24">
        <div className="max-w-3xl">
          <div className="mb-4">
            <p className="text-sm text-gold font-semibold mb-4">✨ Completely Free Platform</p>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-foreground leading-tight">
            Master Your <span className="text-gold">Investment</span> Strategy
          </h1>
          <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
            Precision tools for calculating compound growth, optimal position sizing, and advanced trading strategies. 
            Combine Kelly Criterion, Martingale pyramiding, and compound interest to maximize returns while managing risk.
          </p>
          <div className="divider-gold" />
        </div>
      </section>

      {/* Top Banner Ad - Hero 아래 */}
      <div className="bg-card/50 py-4 border-y border-primary/20">
        <div className="container">
          <AdSense slot="2000000001" format="horizontal" responsive={true} />
        </div>
      </div>

      {/* Menu Cards Grid */}
      <section className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {menuCards.map((card, index) => (
            <div
              key={card.id}
              className="animate-slide-in-up"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <button
                onClick={() => handleCardClick(card.path)}
                onMouseEnter={() => setHoveredCard(card.id)}
                onMouseLeave={() => setHoveredCard(null)}
                className="w-full h-full card-gold-glow p-8 text-left group relative overflow-hidden"
              >
                {/* Background gradient accent */}
                <div
                  className={`absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-300 bg-gradient-to-br ${card.color}`}
                />

                {/* VIP Badge */}
                {card.isVip && (
                  <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-primary/20 border border-primary/50">
                    <span className="text-xs font-semibold text-gold">VIP</span>
                  </div>
                )}

                {/* Content */}
                <div className="relative z-10">
                  {/* Icon */}
                  <div className="mb-6 inline-flex p-3 rounded-lg bg-primary/10 text-gold group-hover:bg-primary/20 transition-colors">
                    {card.icon}
                  </div>

                  {/* Title */}
                  <h3 className="text-2xl font-bold mb-3 text-foreground group-hover:text-gold transition-colors">
                    {card.title}
                  </h3>

                  {/* Description */}
                  <p className="text-muted-foreground mb-6 leading-relaxed">
                    {card.description}
                  </p>

                  {/* CTA */}
                  <div className="flex items-center gap-2 text-gold font-semibold group-hover:gap-3 transition-all">
                    <span>Explore</span>
                    <ChevronRight className="w-5 h-5" />
                  </div>
                </div>
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Mid Banner Ad - 카드 그리드 아래 */}
      <div className="bg-card/50 py-4 border-y border-primary/20">
        <div className="container">
          <AdSense slot="2000000002" format="horizontal" responsive={true} />
        </div>
      </div>

      {/* Features Section */}
      <section className="container py-16 md:py-24">
        <div className="max-w-3xl mb-12">
          <h2 className="text-4xl font-bold mb-4 text-foreground">Why Oracle Trading?</h2>
          <p className="text-muted-foreground text-lg">
            Professional-grade calculation tools designed for serious investors and traders.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              title: 'Precision Calculations',
              description: 'Advanced mathematical models for accurate financial projections and risk assessment.',
            },
            {
              title: 'Real-time Visualization',
              description: 'Interactive charts and graphs showing growth trajectories and risk scenarios.',
            },
            {
              title: 'Integrated Strategy',
              description: 'Combine multiple calculation methods for comprehensive investment planning.',
            },
          ].map((feature, idx) => (
            <div
              key={idx}
              className="p-6 rounded-lg border border-primary/20 bg-card/50 hover:bg-card/80 hover:border-primary/50 transition-all"
            >
              <h4 className="text-lg font-semibold mb-3 text-gold">{feature.title}</h4>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Bottom Banner Ad - Features 아래 */}
      <div className="bg-card/50 py-4 border-y border-primary/20">
        <div className="container">
          <AdSense slot="2000000003" format="horizontal" responsive={true} />
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-primary/20 bg-card/50 backdrop-blur-sm mt-12">
        <div className="container py-8 text-center text-muted-foreground text-sm">
          <p>Oracle Trading © 2026. Professional Investment Strategy Calculator.</p>
          <p className="mt-2">Disclaimer: For educational purposes only. Always consult with a financial advisor.</p>
        </div>
      </footer>
    </div>
  );
}
