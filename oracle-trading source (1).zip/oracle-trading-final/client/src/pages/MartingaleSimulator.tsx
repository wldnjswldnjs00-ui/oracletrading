import { useState, useMemo } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft, AlertTriangle, Info } from 'lucide-react';
import { toast } from 'sonner';
import { calculateMartingale } from '@/lib/calculators';
import AdSense from '@/components/AdSense';
import SidebarAds from '@/components/SidebarAds';
import { EducationAccordion } from '@/components/EducationAccordion';



export default function MartingaleSimulator() {
  const [, setLocation] = useLocation();
  
  const [startingCapital, setStartingCapital] = useState(10000);
  const [currentPrice, setCurrentPrice] = useState(100);
  const [drawdownPercent, setDrawdownPercent] = useState(5);
  const [shareQuantities, setShareQuantities] = useState([10, 15, 20, 25]);

  const result = useMemo(() => {
    return calculateMartingale(currentPrice, drawdownPercent, shareQuantities, 2, startingCapital);
  }, [currentPrice, drawdownPercent, shareQuantities, startingCapital]);

  const addLevel = () => {
    setShareQuantities([...shareQuantities, shareQuantities[shareQuantities.length - 1] * 1.5]);
  };

  const removeLevel = () => {
    if (shareQuantities.length > 1) {
      setShareQuantities(shareQuantities.slice(0, -1));
    }
  };

  const updateShareQuantity = (index: number, value: number) => {
    const newQuantities = [...shareQuantities];
    newQuantities[index] = Math.max(0, value);
    setShareQuantities(newQuantities);
  };

  const handleCalculate = () => {
    toast.success(`Calculation complete! Break-even price: $${result.breakEvenPrice.toFixed(2)}`);
  };

  const getRiskColor = (assessment: string) => {
    if (assessment.includes('EXTREME')) return 'text-destructive';
    if (assessment.includes('HIGH')) return 'text-orange-500';
    if (assessment.includes('MODERATE')) return 'text-yellow-500';
    return 'text-green-500';
  };

  // Calculate totals
  const totalShares = shareQuantities.reduce((a, b) => a + b, 0);
  const totalCapitalInvested = shareQuantities.reduce((sum, qty, idx) => {
    const price = currentPrice * Math.pow(1 - drawdownPercent / 100, idx);
    return sum + qty * price;
  }, 0);
  const averageEntryPrice = totalShares > 0 ? totalCapitalInvested / totalShares : 0;

  // Calculate maximum levels based on starting capital
  const maxLevelsAffordable = Math.floor(Math.log(startingCapital / totalCapitalInvested + 1) / Math.log(1 + drawdownPercent / 100));

  // Chrome translation safe number parser
  const parseNum = (val: string) => {
    const n = parseFloat(val.replace(/[^0-9.\-]/g, ''));
    return isNaN(n) ? 0 : n;
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-primary/20 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center gap-4">
          <button
            onClick={() => setLocation('/')}
            className="p-2 hover:bg-primary/10 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gold" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Martingale Simulator</h1>
            <p className="text-sm text-muted-foreground">Model pyramid entry strategies with share-based averaging</p>
          </div>
        </div>
      </header>

      {/* Top Banner Ad */}
      <div className="bg-card/50 py-4 border-b border-primary/20">
        <div className="container">
          <AdSense slot="1234567897" format="horizontal" responsive={true} />
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-12">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Sidebar Ads */}
          <div className="hidden lg:block">
            <SidebarAds />
          </div>

          {/* Left: Input Form */}
          <div className="lg:col-span-1">
            <div className="card-gold-glow p-6 sticky top-24">
              <h2 className="text-xl font-bold mb-6 text-foreground">Strategy Configuration</h2>

              {/* Available Capital */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-muted-foreground mb-2">
                  Available Capital
                </label>
                <input
                  type="number"
                  value={startingCapital}
                  onChange={(e) => setStartingCapital(Math.max(0, parseNum(e.target.value)))}
                  className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                />
                <p className="text-xs text-muted-foreground mt-1">Your total capital for this strategy</p>
              </div>

              {/* Current Asset Price */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-muted-foreground mb-2">
                  Current Price per Unit
                </label>
                <input
                  type="number"
                  value={currentPrice}
                  onChange={(e) => setCurrentPrice(Math.max(0.01, parseNum(e.target.value)))}
                  step="0.01"
                  className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                />
                <p className="text-xs text-muted-foreground mt-1">Current price of the stock / coin / asset</p>
              </div>

              {/* Price Drop Percent */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-muted-foreground mb-2">
                  Price Drop Between Entries (%)
                </label>
                <input
                  type="number"
                  value={drawdownPercent}
                  onChange={(e) => setDrawdownPercent(Math.max(0.1, parseNum(e.target.value)))}
                  step="0.5"
                  className="w-full px-3 py-2 rounded-lg bg-input border border-primary/20 text-foreground font-mono text-sm focus:outline-none focus:border-primary"
                />
                <p className="text-xs text-muted-foreground mt-1">Buy again when price drops this % (e.g., 5% = -5%, -10%, -15%)</p>
              </div>

              {/* Add/Remove Levels */}
              <div className="flex gap-2">
                <button
                  onClick={addLevel}
                  className="flex-1 px-3 py-2 rounded-lg bg-green-600 text-white font-semibold text-sm hover:bg-green-500 transition-colors"
                >
                  + Add Level
                </button>
                <button
                  onClick={removeLevel}
                  className="flex-1 px-3 py-2 rounded-lg bg-destructive/20 text-destructive font-semibold text-sm hover:bg-destructive/30 transition-colors"
                >
                  - Remove
                </button>
              </div>
            </div>
          </div>

          {/* Center: Entry Levels Detail */}
          <div className="lg:col-span-1">
            <div className="card-gold-glow p-6 sticky top-24">
              <h3 className="text-lg font-bold mb-4 text-foreground">Entry Levels</h3>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {shareQuantities.map((qty, idx) => {
                  const price = currentPrice * Math.pow(1 - drawdownPercent / 100, idx);
                  const investment = qty * price;
                  return (
                    <div key={idx} className="bg-primary/10 p-3 rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-xs font-bold text-gold">Level {idx + 1}</span>
                        <span className="text-xs text-accent">{price.toFixed(2)}</span>
                      </div>
                      <input
                        type="number"
                        value={qty}
                        onChange={(e) => updateShareQuantity(idx, parseNum(e.target.value))}
                        className="w-full px-2 py-1 rounded bg-input border border-primary/20 text-foreground font-mono text-xs mb-2 focus:outline-none focus:border-primary"
                        placeholder="Quantity"
                      />
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Capital:</span>
                          <span className="font-mono text-gold">{investment.toFixed(0)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">% of Total:</span>
                          <span className="font-mono text-accent">{totalCapitalInvested > 0 ? ((investment / totalCapitalInvested) * 100).toFixed(1) : 0}%</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Totals */}
              <div className="mt-4 pt-4 border-t border-primary/20 space-y-2">
                <div className="flex justify-between">
                  <span className="text-xs text-muted-foreground">Total Quantity:</span>
                  <span className="text-sm font-bold text-gold font-mono">{totalShares.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-muted-foreground">Total Capital:</span>
                  <span className="text-sm font-bold text-gold font-mono">{totalCapitalInvested.toFixed(0)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-muted-foreground">Avg Entry Price:</span>
                  <span className="text-sm font-bold text-accent font-mono">{averageEntryPrice.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-2 space-y-6">
            {/* Key Results */}
            <div className="space-y-4">
              {/* Break-Even Price */}
              <div className="card-gold-glow p-5">
                <p className="text-xs text-muted-foreground mb-2">Break-Even Price</p>
                <p className="text-2xl font-bold text-gold font-mono">
                  {result.breakEvenPrice.toFixed(2)}
                </p>
                <p className="text-xs text-accent mt-2">
                  {result.breakEvenPrice > currentPrice
                    ? `↑ ${((result.breakEvenPrice / currentPrice - 1) * 100).toFixed(1)}% above current`
                    : `↓ ${((1 - result.breakEvenPrice / currentPrice) * 100).toFixed(1)}% below current`}
                </p>
              </div>

              {/* Total Capital Required */}
              <div className="card-gold-glow p-5">
                <p className="text-xs text-muted-foreground mb-2">Total Investment Required</p>
                <p className="text-2xl font-bold text-gold font-mono">
                  {result.totalCapitalRequired.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                </p>
                <p className="text-xs text-accent mt-2">Sum of all entry levels</p>
              </div>

              {/* Risk Assessment */}
              <div className={`card-gold-glow p-5 border-l-4 border-gold ${getRiskColor(result.riskAssessment)}`}>
                <p className="text-xs text-muted-foreground mb-2">Risk Assessment</p>
                <p className="text-sm font-bold mb-1">{result.riskAssessment}</p>
                <p className="text-xs text-muted-foreground">
                  {result.riskAssessment.includes('EXTREME')
                    ? 'Very high capital requirement. Extreme caution advised.'
                    : result.riskAssessment.includes('HIGH')
                    ? 'High capital requirement. Consider reducing positions.'
                    : result.riskAssessment.includes('MODERATE')
                    ? 'Moderate risk. Suitable for experienced traders.'
                    : 'Low risk. Conservative strategy suitable for most.'}
                </p>
              </div>
            </div>

            {/* Strategy Notes */}
            <div className="card-gold-glow p-5 border-l-4 border-gold">
              <div className="flex gap-2 mb-3">
                <Info className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                <h4 className="text-sm font-bold text-foreground">How This Works</h4>
              </div>
              <div className="space-y-2 text-xs text-muted-foreground">
                <p>
                  <strong className="text-foreground">1. Buy at Current Price:</strong> Purchase {shareQuantities[0]} units at {currentPrice.toFixed(2)}
                </p>
                <p>
                  <strong className="text-foreground">2. Price Drops {drawdownPercent}%:</strong> Buy {shareQuantities[1]} more units at {(currentPrice * (1 - drawdownPercent / 100)).toFixed(2)}
                </p>
                <p>
                  <strong className="text-foreground">3. Continue Buying:</strong> Repeat for all {shareQuantities.length} levels as price drops
                </p>
                <p>
                  <strong className="text-foreground">4. Exit at Break-Even:</strong> Sell all {totalShares.toFixed(0)} units at {result.breakEvenPrice.toFixed(2)} to recover your capital
                </p>
              </div>
            </div>

            {/* Profit at Different Prices */}
            <div className="card-gold-glow p-5">
              <h3 className="text-sm font-bold mb-3 text-foreground">Profit at Different Prices</h3>
              <div className="space-y-2 text-xs">
                {[
                  { price: averageEntryPrice * 1.05, label: '+5% from avg' },
                  { price: averageEntryPrice * 1.10, label: '+10% from avg' },
                  { price: averageEntryPrice * 1.20, label: '+20% from avg' },
                ].map((scenario, idx) => {
                  const profit = (scenario.price - averageEntryPrice) * totalShares;
                  return (
                    <div key={idx} className="flex justify-between p-2 bg-primary/10 rounded">
                      <span className="text-muted-foreground">{scenario.label}</span>
                      <span className="font-mono font-semibold text-accent">
                        {profit.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Strategy Warnings */}
            <div className="card-gold-glow p-5 border-l-4 border-gold">
              <div className="flex gap-2">
                <AlertTriangle className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-semibold text-foreground mb-1">Strategy Notes</p>
                  <p className="text-xs text-muted-foreground">
                    Works best in ranging markets. Stop buying if price continues falling beyond your capital limit. Consider your risk tolerance carefully.
                  </p>
                </div>
              </div>
            </div>

            {/* Education Section */}
            <div className="card-gold-glow p-6">
              <h3 className="text-lg font-bold mb-4 text-foreground">📖 Learn About Martingale Strategy</h3>
              <EducationAccordion sections={[
                {
                  title: '📚 What is Martingale Strategy?',
                  content: `The Martingale strategy is a pyramid entry technique where you buy more units as the price drops. Each level purchases additional units at progressively lower prices, reducing your average entry price and creating a break-even point closer to your initial entry.`,
                },
                {
                  title: '🎯 Why Use Martingale?',
                  content: `• Lower Average Price: Each buy reduces your average entry cost
• Break-Even Recovery: Reach profitability at lower price levels
• Capital Efficiency: Deploy capital strategically across levels
• Flexible Sizing: Adjust quantities per level based on risk tolerance
• Profit Potential: Significant gains once price recovers`,
                },
                {
                  title: '✅ Advantages',
                  content: `1. Reduced Average Price: Systematically lowers entry cost
2. Recovery Potential: Break-even at much lower prices
3. Flexible: Customize levels and quantities
4. Psychological: Feels like you're "averaging down"
5. Scalable: Works with any asset class`,
                },
                {
                  title: '⚠️ Disadvantages',
                  content: `1. Capital Intensive: Requires significant capital for multiple levels
2. Price Continuation Risk: If price keeps falling, you run out of capital
3. Timing Dependent: Works only if price eventually recovers`,
                },
                {
                  title: '🚨 Risk Factors',
                  content: `• Unlimited Loss Potential: If price never recovers, losses accumulate
• Capital Depletion: Running out of money before price recovers
• Forced Liquidation: May need to sell at loss if capital runs out
• Psychological Stress: Watching losses mount can cause panic selling
• Market Collapse: Extreme price drops can wipe out entire position`,
                },
                {
                  title: '💡 Tips & Best Practices',
                  content: `1. Set Capital Limits: Define maximum capital before starting
2. Use Stop Loss: Don't buy beyond your predetermined limit
3. Trending Markets: Avoid in strong downtrends
4. Ranging Markets: Best in sideways or mean-reverting markets
5. Position Size: Start small, increase gradually
6. Monitor Carefully: Track each level's performance
7. Exit Strategy: Plan your exit before entering`,
                },
                {
                  title: '📖 How to Use This Calculator',
                  content: `Starting Capital: Your total available capital for the strategy

Current Price: The initial entry price of the asset

Price Drop Between Entries (%): Percentage drop before buying next level
• 5% = Buy every 5% drop (aggressive)
• 10% = Buy every 10% drop (moderate)
• 20% = Buy every 20% drop (conservative)

Share Quantities: Number of shares to buy at each level
• Level 1: Initial purchase
• Level 2: Buy more when price drops
• Continue for each level

+ Add Level: Add another buying level
- Remove: Remove the last level

Results:
• Total Shares: Total units purchased across all levels
• Total Invested: Total capital deployed
• Average Entry Price: Weighted average price of all purchases
• Break-Even Price: Price needed to recover all capital
• Risk Assessment: Overall risk level of your configuration`,
                },
              ]} />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Banner Ad */}
      <div className="bg-card/50 py-4 border-t border-primary/20 mt-12">
        <div className="container">
          <AdSense slot="1234567898" format="horizontal" responsive={true} />
        </div>
      </div>
    </div>
  );
}
