import { useState } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft, BarChart3, TrendingUp, PieChart } from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart as RechartsPie,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { RiskIndicator, RiskGauge, StatusBadge } from '@/components/RiskIndicator';

/**
 * Dashboard Page
 * 
 * Visual dashboard showing risk metrics and projections
 */

export default function Dashboard() {
  const [, setLocation] = useLocation();
  
  // Sample data for visualization
  const growthData = [
    { month: 1, balance: 10000, invested: 10000, profit: 0 },
    { month: 2, balance: 10500, invested: 11000, profit: -500 },
    { month: 3, balance: 11550, invested: 12000, profit: -450 },
    { month: 4, balance: 12705, invested: 13000, profit: -295 },
    { month: 5, balance: 13977, invested: 14000, profit: -23 },
    { month: 6, balance: 15375, invested: 15000, profit: 375 },
    { month: 7, balance: 16912, invested: 16000, profit: 912 },
    { month: 8, balance: 18603, invested: 17000, profit: 1603 },
    { month: 9, balance: 20463, invested: 18000, profit: 2463 },
    { month: 10, balance: 22509, invested: 19000, profit: 3509 },
    { month: 11, balance: 24760, invested: 20000, profit: 4760 },
    { month: 12, balance: 27236, invested: 21000, profit: 6236 },
  ];

  const strategyComparison = [
    { name: 'Conservative', value: 8500, fill: '#00D9FF' },
    { name: 'Balanced', value: 12500, fill: '#FFD700' },
    { name: 'Aggressive', value: 18000, fill: '#FFA500' },
  ];

  const riskMetrics = [
    { name: 'Kelly', value: 65 },
    { name: 'Martingale', value: 45 },
    { name: 'Compound', value: 30 },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-primary/20 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center gap-4">
          <button
            onClick={() => setLocation('/')}
            className="p-2 hover:bg-primary/10 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gold" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Visualization Dashboard</h1>
            <p className="text-sm text-muted-foreground">Real-time risk metrics and projections</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-12">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="card-gold-glow p-6">
            <p className="text-sm text-muted-foreground mb-2">Current Balance</p>
            <p className="text-3xl font-bold text-gold font-mono">$27,236</p>
            <p className="text-xs text-accent mt-2">+6,236 profit</p>
          </div>

          <div className="card-gold-glow p-6">
            <p className="text-sm text-muted-foreground mb-2">Total Invested</p>
            <p className="text-3xl font-bold text-accent font-mono">$21,000</p>
            <p className="text-xs text-muted-foreground mt-2">Over 12 months</p>
          </div>

          <div className="card-gold-glow p-6">
            <p className="text-sm text-muted-foreground mb-2">ROI</p>
            <p className="text-3xl font-bold text-gold font-mono">29.7%</p>
            <p className="text-xs text-accent mt-2">Annualized</p>
          </div>

          <div className="card-gold-glow p-6">
            <p className="text-sm text-muted-foreground mb-2">Risk Level</p>
            <p className="text-3xl font-bold text-yellow-500 font-mono">Moderate</p>
            <p className="text-xs text-muted-foreground mt-2">Manageable</p>
          </div>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Growth Chart */}
          <div className="card-gold-glow p-8">
            <h3 className="text-lg font-bold mb-6 text-foreground flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-gold" />
              Growth Projection
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={growthData}>
                <defs>
                  <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="rgba(255, 215, 0, 0.8)" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="rgba(255, 215, 0, 0)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 215, 0, 0.1)" />
                <XAxis dataKey="month" stroke="rgba(255, 215, 0, 0.5)" />
                <YAxis stroke="rgba(255, 215, 0, 0.5)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(10, 14, 39, 0.95)',
                    border: '1px solid rgba(255, 215, 0, 0.3)',
                    borderRadius: '8px',
                    color: '#F5F5F5',
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="balance"
                  stroke="rgba(255, 215, 0, 1)"
                  strokeWidth={2}
                  name="Balance"
                />
                <Line
                  type="monotone"
                  dataKey="invested"
                  stroke="rgba(0, 217, 255, 0.7)"
                  strokeWidth={2}
                  name="Invested"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Strategy Comparison */}
          <div className="card-gold-glow p-8">
            <h3 className="text-lg font-bold mb-6 text-foreground flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-gold" />
              Strategy Comparison
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={strategyComparison}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 215, 0, 0.1)" />
                <XAxis dataKey="name" stroke="rgba(255, 215, 0, 0.5)" />
                <YAxis stroke="rgba(255, 215, 0, 0.5)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(10, 14, 39, 0.95)',
                    border: '1px solid rgba(255, 215, 0, 0.3)',
                    borderRadius: '8px',
                    color: '#F5F5F5',
                  }}
                />
                <Bar dataKey="value" name="12-Month Balance">
                  {strategyComparison.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Risk Assessment */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Risk Indicators */}
          <div className="card-gold-glow p-8">
            <h3 className="text-lg font-bold mb-6 text-foreground">Risk Indicators</h3>
            <div className="space-y-6">
              <RiskGauge value={45} label="Kelly Criterion Risk" />
              <RiskGauge value={65} label="Martingale Risk" />
              <RiskGauge value={30} label="Compound Growth Risk" />
            </div>
          </div>

          {/* Risk Assessment */}
          <div className="card-gold-glow p-8">
            <h3 className="text-lg font-bold mb-6 text-foreground">Overall Assessment</h3>
            <div className="space-y-4">
              <RiskIndicator
                capitalRequired={50000}
                winRate={55}
                profitRatio={2}
                lossRatio={1}
              />
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">Win Rate</p>
                  <StatusBadge status="success" label="55%" />
                </div>
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">Risk-Reward Ratio</p>
                  <StatusBadge status="info" label="1:2" />
                </div>
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">Capital Required</p>
                  <StatusBadge status="warning" label="$50K" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Metrics Table */}
        <div className="card-gold-glow p-8">
          <h3 className="text-lg font-bold mb-6 text-foreground">Monthly Performance</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-primary/20">
                  <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Month</th>
                  <th className="text-right py-3 px-4 text-muted-foreground font-semibold">Balance</th>
                  <th className="text-right py-3 px-4 text-muted-foreground font-semibold">Invested</th>
                  <th className="text-right py-3 px-4 text-muted-foreground font-semibold">Profit</th>
                  <th className="text-right py-3 px-4 text-muted-foreground font-semibold">ROI</th>
                </tr>
              </thead>
              <tbody>
                {growthData.map((row) => (
                  <tr key={row.month} className="border-b border-primary/10 hover:bg-primary/5">
                    <td className="py-3 px-4 text-foreground">Month {row.month}</td>
                    <td className="text-right py-3 px-4 text-gold font-mono font-semibold">
                      ${row.balance.toLocaleString()}
                    </td>
                    <td className="text-right py-3 px-4 text-accent font-mono">
                      ${row.invested.toLocaleString()}
                    </td>
                    <td className="text-right py-3 px-4 text-accent font-mono">
                      ${row.profit.toLocaleString()}
                    </td>
                    <td className="text-right py-3 px-4 text-gold font-mono">
                      {((row.profit / row.invested) * 100).toFixed(1)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
