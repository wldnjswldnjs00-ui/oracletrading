import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import CompoundCalculator from "./pages/CompoundCalculator";
import KellyCalculator from "./pages/KellyCalculator";
import MartingaleSimulator from "./pages/MartingaleSimulator";
import VIPStrategy from "./pages/VIPStrategy";
import Dashboard from "./pages/Dashboard";


function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/compound-calculator" component={CompoundCalculator} />
      <Route path="/kelly-calculator" component={KellyCalculator} />
      <Route path="/martingale-simulator" component={MartingaleSimulator} />
      <Route path="/vip-strategy" component={VIPStrategy} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/404" component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
